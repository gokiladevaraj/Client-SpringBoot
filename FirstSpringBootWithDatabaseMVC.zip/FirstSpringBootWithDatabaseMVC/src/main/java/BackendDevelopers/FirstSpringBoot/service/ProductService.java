package BackendDevelopers.FirstSpringBoot.service;
import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import BackendDevelopers.FirstSpringBoot.dao.ProductList;
import BackendDevelopers.FirstSpringBoot.model.Product;
/*Any class marked as service controls concurrent or parallel
 * access to the DAO layer, there by preventing data loss or data 
 * ambiguity or data corruption.
 * 
 * @Service automatically create a bean for ProductService
 */
@Service
public class ProductService {
	//Manually injecting the ProductList object into this service.
	//@autowired means dependency injection
	@Autowired
	ProductList pList;
	 public ArrayList<Product> getProductList(){
		 System.out.println("Getting Product List...");
		 //When you call findAll() method in the repository, it
		 //executes a SQL SELECT* from Products statement on the
		 //database.
		return  (ArrayList<Product>)pList.findAll();
		 
	 }
	public Product addProduct(Product p) {
		System.out.println("Adding product..");
		Product t=pList.save(p);
		return t;
		
	}
	public String deleteProduct(int productId) {
	    if (pList.existsById(productId)) {
	        pList.deleteById(productId);
	        return "✅ Product with ID " + productId + " deleted successfully.";
	    } else {
	        return "❌ Product with ID " + productId + " not found.";
	    }
	}
  
    public String searchById(int productId) {
	 System.out.println("In service. Searching by the Id....");
	 //If productId is 4, this is converted to SQL
	 //SELECT*from Product where productId=4
	 Optional<Product> opt= pList.findById(productId);
	 return "<b>Located Product</b>"+opt.get().toString();
	
	 
   }
    public String updateProduct(int productId, String newProductName)
    {
 	   System.out.println("In service Updating product");
 	   Product d=new Product(productId, newProductName);
 	   //when save() is called, if any product with
 	   //given productId is existing, it updated productName with
 	   //newProductname. Otherwise it inserts a new record.
 	   pList.save(d);
 	   return "<b>Updated product with"+pList.save(d).toString();
 	 
 	 
    }



    


}
