package BackendDevelopers.FirstSpringBoot.model;

//To import all the annotation 
import jakarta.persistence.*;

//Linking the POJO class to the table in the database.
@Entity
@Table(name="Product")
public class Product {
	@Id //In the database this column is a primary key
	//For generating primary key values automatically
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private int productId;
	//Link productName variable with productName column in the database
	@Column(name="productName")
	private String productName;

	public Product() {
		super();
		System.out.println("New Product Created...");
		}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + "]"+"   -   "+hashCode();
	}

	public Product(int productId, String productName) {
		super();
		this.productId = productId;
		this.productName = productName;
		System.out.println("New Product Created... With productId and productName");
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
		System.out.println("Stored productId");
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
		System.out.println("Stored productName");
	}

}
