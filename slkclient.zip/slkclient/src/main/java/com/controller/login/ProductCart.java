package com.controller.login;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * Servlet implementation class ProductCart
 */
@WebServlet("/ProductCart")
public class ProductCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 public Map<String, Integer> product=new HashMap<>();

    /**
     * Default constructor. 
     */
    public ProductCart() {
        // TODO Auto-generated constructor stub
    	product.put("Tshirt", 399);
    	product.put("Saree", 1999);
    	product.put("Shirt", 599);
    	product.put("Jeans", 899);
    	product.put("Towser", 699);
    	product.put("Chutithar", 1899);
    	product.put("Nightsuit", 999);
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.service(request, response);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		 int num=1;
		for(Map.Entry<String, Integer> iteams:product.entrySet()) {
		     pw.println("<html><body><h3>"+num+" "+iteams.getKey()+" "+iteams.getValue()+"</html></body></h3>");
		      num++;
		}
			}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String productName=request.getParameter("productName");
		String productPrice=request.getParameter("productPrice");
		System.out.println(productName+" "+productPrice);
	}

}
