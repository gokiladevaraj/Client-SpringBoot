package BackendDevelopers.FirstSpringBoot.controllers;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import BackendDevelopers.FirstSpringBoot.model.Product;
import BackendDevelopers.FirstSpringBoot.service.ProductService;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
//convert a normal java class into a controller.controller has one or more APIs
@RestController
@RequestMapping("/shopping")
public class Shopping {
	public long visitorCount=0;
	@Autowired
	ProductService service;
	public Shopping() {
		System.err.println("Shopping controller created...");
	}
	//link this API with the browser
	//if the url is http://localhost:8080/shopping/,then call
	//home() method and return response to the client.
	@RequestMapping(path="/", method=RequestMethod.GET)
	public String home() { 
		visitorCount++;
		//preparing the response and send it to the client. 
		String response="<html><body><h1>";
		response+="Welcome to online shopping</h1><b>";
		response+="<b>You are a visitor #<br>"+visitorCount;
		response+="</body></html>";
		return response;
	}
	@GetMapping(path="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public Map<Integer, Product> getProductList()
	{
		return service.getProductList();//sending the response
	}
	/*@RequestParam indicates that the value for productId is sent
	 * at the end of the url, when data is semt in the url as a key-value pair.
	 * @PathParam is used to retrieve the data using the key. Retrieved data is stored 
	 * into productId.
	 */
	
   //@RequestParam indicates the that the value for  productId is send at the end of url
	@GetMapping("/search")
	public String searchProduct(@RequestParam("pId") int productId)
	{
		return service.searchById(productId);
		
	}
	/*@DeleteMapping is used to handle http Delete request, if DELETE request is sent, then
	 * deleteProduct() method is called to delete the product
	 * @equestBody is used when the client send data from a HTML form using 
	 * either post request or put request ot delete request or update request.
	 * RequestBody contains the data sent by the client.
	 */
	@DeleteMapping(path="/deleteId/{pId}")
	public String deleteProduct(@PathVariable("pId") int productId) {
		System.err.println("Got a request...");
		return service.deleteProduct(productId);
		}
	/*@PostMapping is used receive post request from the client. If the url ends
	 * with /add and request type is POST, then addProduct() method called to
	 * add a new product to the hashMap
	 * When the post request is issued by the client, data is set inside the request packet.
	 * so to read the data, use @RequestBody annotation.
	 * POST request must be stored in an object only.so we have to define a POJO class
	 *  called Product
	 * Every API must declare the MIME  format in which it accepts the data.
	 * consumes attributes makes the sever to accept the data in specific format only
	 * the client has to send the data in the format of declared.
	 * 
	 * Dependency Injection is followed. The object p for the product class is automatically
	 * created and managed by spring boot framework.so p is a managed object also
	 * called as java bean.
	 */  
	@PostMapping(path="/add", consumes=MediaType.APPLICATION_JSON_VALUE)
	public String addProduct(@RequestBody Product p)
	{
		return service.addProduct(p);
		//System.out.println(p.toString());	
	}
	@PutMapping(path="/update", consumes=MediaType.APPLICATION_JSON_VALUE)
	public String updateProduct(@RequestBody Product p)
	{
		System.out.println("Got a Post Request...");
		return service.updateProduct(p.getProductId(), p.getProductName());
		 
		//System.out.println(p.toString());	
	}
	/*@PatchMapping(path="/patch", consumes=MediaType.APPLICATION_JSON_VALUE)
	public Map<Integer, String> patchProduct(@RequestBody Product p)
	{
		System.out.println("Got a Patch Request...");
		 int productId = p.getProductId();
		 String productName = p.getProductName();
		    products.put(productId, productName);
		  return products;
		//System.out.println(p.toString());	)*/
}
