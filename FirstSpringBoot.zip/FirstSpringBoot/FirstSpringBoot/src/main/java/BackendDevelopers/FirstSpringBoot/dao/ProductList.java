package BackendDevelopers.FirstSpringBoot.dao;

import java.util.HashMap;

import BackendDevelopers.FirstSpringBoot.model.Product;

public class ProductList {
	public HashMap<Integer, Product> productList=new HashMap<>(); 
	 public ProductList() {
			super();
			productList.put(1,new Product(1,"Samsung ZFod"));
			productList.put(2, new Product(2,"Iphone 17 pro Max"));
			productList.put(3, new Product(3,"Nexus s70"));
			productList.put(4, new Product(4,"Samsung A55"));
			System.out.println("Product List Created..............");
		}
	 public HashMap<Integer, Product> getProductList(){
		 System.out.println("Retrieved product list and send it...");
		 return productList;
	 }
	 
			public String addProduct(Product p) {
				productList.put(p.getProductId(), p);
				System.err.println("Added a new Product..");
				return "<b>Product added successfully."
						+"Use /list to get updated list of products...";
			}
		   public String deleteProduct(int productId)
		   {
			   Product p=productList.get(productId);
				if(p!=null)
				{
					productList.remove(productId);
					return "<b>Product found and Deleted</b>&nbsp;" + p;
				}
				else
					return "<b>Product Not found</b>";
			   
		   }
		  
		 public String searchById(int productId) {
			 Product p=productList.get(productId);
				if(p!=null)
				{
					return "<b>Product found</b>&nbsp;" + p;
				}
				else
					return "<b>Product Not found</b>";
		   }
		   public String updateProduct(int productId, String newProductName)
		   {
			  Product p=productList.get(productId);
			  if(p!=null)
			  {
				  p.setProductName(newProductName);
				  productList.put(p.getProductId(), p);
				  return "<b>Product found and updated...</b>";
			  }
			  else
			  {
				  return "<b>Product Not found</b>";
			  }
				 /*if(productList.containsKey(productId1))
				 {
				  productList.put(productId1, productName);
				  return "Product Updated";
				 }
				 else
				 {
					return "Product Not Found";
				 }*/
		   }

}
