package BackendDevelopers.FirstSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSpringBootApplication {

	//Entry point for Springboot application
	public static void main(String[] args) {
		
		//Start the tomcat server and deploys the application or webSites on tomcat server
		SpringApplication.run(FirstSpringBootApplication.class, args);
		System.out.println("Started the server....");
	}

}
