package BackendDevelopers.FirstSpringBoot.service;
import java.util.HashMap;
import org.springframework.stereotype.Service;
import BackendDevelopers.FirstSpringBoot.dao.ProductList;
import BackendDevelopers.FirstSpringBoot.model.Product;
/*Any class marked as service controls concurrent or parallel
 * access to the DAO layer, there by preventing data loss or data 
 * ambiguity or data corruption.
 * 
 * @Service automatically create a bean for ProductService
 */
@Service
public class ProductService {
	//Manually injecting the ProductList object into this service.
	ProductList pList=new ProductList();
	 public HashMap<Integer, Product> getProductList(){
		 System.out.println("Getting Product List...");
		 return pList.getProductList();
	 }
	public String addProduct(Product p) {
		System.out.println("Adding product..");
		return  pList.addProduct(p);
	}
   public String deleteProduct(int productId)
   {
	   System.out.println("In Service. Deleteting the Product");
	   return pList.deleteProduct(productId);
   }
  
 public String searchById(int productId) {
	 System.out.println("In service. Searching the product");
	 return pList.searchById(productId);
	 
   }
   public String updateProduct(int productId, String newProductName)
   {
	   System.out.println("In service Updating product");
	   return pList.updateProduct(productId, newProductName);
	 
   }

}
