package CricketTeam.Ipl2025.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/ipl2025")
public class IplTeams {
	public int visitorCount=0;
	public Map<String, String> teams=new HashMap<>();
	public IplTeams() {
		teams.put("MI", "Mumbai Indians");
		teams.put("CSK", "Chennai Super Kings");
		teams.put("RCB", "Royal Challenges Bengaluru");
		teams.put("GT", "Gujarat Titans");
		teams.put("RR", "Rajasthan Royals");
		teams.put("LSG", "Lucknow Super Giants");
		teams.put("DC", "Delhi capitals");	
	}
@RequestMapping(path="/",method=RequestMethod.GET)
public String home() {
	visitorCount++;
	//preparing the response and send it to the client. 
	String response="<html><body><h1>";
	response+="Welcome to IPL2025 Teams</h1><b>";
	response+="<b>You are a visitor #<br>"+visitorCount;
	response+="</body></html>";
	return response;
}
@GetMapping("/list")
public Map<String, String> getIplTeams(){
	return teams;
}
@GetMapping("/search")
public String SearchTeams(@RequestParam("team") String iplTeam)
{
	String tname=teams.get(iplTeam);
	if(tname!=null)
	{
		return "<b>Team</b>&nbsp;" + tname;
	}
	else
		return "<b>Team not found ! Please add the team</b>&nbsp;";
}
@DeleteMapping(path="/delete/{team}")
public String deleteTeam(@PathVariable("team") String iplTeam )
{
	String tname=teams.get(iplTeam);
	if(tname!=null)
	{
		teams.remove(iplTeam);
		return "<b>Team</b>&nbsp;" + tname;
	}
	else
		return "<b>Team not found ! Please add the team</b>&nbsp;";
}
@PostMapping("/add/{team}/{TeamName}")
public String addProduct(@PathVariable("team") String iplTeam,
                         @PathVariable("TeamName") String iplTeams) {
    if (teams.containsKey(iplTeam)) {
        return "<b>Team already exists:</b> " + teams.get(iplTeam);
    }
    teams.put(iplTeam, iplTeams);
    return "<b>New product added:</b> " + iplTeam + " - " + iplTeams;
}

}
