package CricketTeam.Ipl2025.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import CricketTeam.Ipl2025.model.Team;
import CricketTeam.Ipl2025.service.TeamService;


@RestController
@RequestMapping("/ipl2025")
public class IplTeams {
	public int visitorCount=0;
	
	
	@Autowired
	TeamService service;
	public IplTeams() {
		System.err.print("Team controller is created....");
	}
@RequestMapping(path="/",method=RequestMethod.GET)
public String home() {
	visitorCount++;
	//preparing the response and send it to the client. 
	String response="<html><body><h1>";
	response+="Welcome to IPL2025 Teams</h1><b>";
	response+="<b>You are a visitor #<br>"+visitorCount;
	response+="</body></html>";
	return response;
}
@GetMapping(path="/list",produces=MediaType.APPLICATION_JSON_VALUE)
public  ArrayList<Team> getTeamList()
{
	return service.getTeamList();//sending the response
}
@GetMapping(path="/search")
public String searchTeam(@RequestParam("pId") String teamId)
{
	return service.searchById(teamId);
	
}
@DeleteMapping(path="/deleteId/{pId}")
public String deleteTeam(@PathVariable("pId") String teamId) {
	System.err.println("Got a request...");
	return service.deleteTeam(teamId);
	}
@PostMapping(path="/add", consumes=MediaType.APPLICATION_JSON_VALUE)
public String addTeam(@RequestBody Team p)
{
	return service.addTeam(p);
	//System.out.println(p.toString());	
}
@PutMapping(path="/update", consumes=MediaType.APPLICATION_JSON_VALUE)
public String updateTeam(@RequestBody Team p)
{
	System.out.println("Got a Post Request...");
	return service.updateTeam(p.getTeamId(), p.getTeamName());
	 
	//System.out.println(p.toString());	
}

}

