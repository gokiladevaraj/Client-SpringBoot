package CricketTeam.Ipl2025.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import CricketTeam.Ipl2025.model.Team;

@Repository
public interface TeamList extends CrudRepository<Team, String>{
		/*CrudRepository<Product, Integer> 
		 * product is the data that will inserted into the database
		 * or retrieved from the database.
		 * Integer is the datatype of the primary key.
		 */
		
	}


