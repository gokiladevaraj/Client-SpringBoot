package CricketTeam.Ipl2025.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import CricketTeam.Ipl2025.dao.TeamList;
import CricketTeam.Ipl2025.model.Team;

@Service
public class TeamService {
	//Manually injecting the ProductList object into this service.
	//@autowired means dependency injection
	@Autowired
	TeamList tList;
	 public ArrayList<Team> getTeamList(){
		 System.out.println("Getting Team List...");
		 //When you call findAll() method in the repository, it
		 //executes a SQL SELECT* from Products statement on the
		 //database.
		return  (ArrayList<Team>)tList.findAll();
		 
	 }
	public String addTeam(Team p) {
		System.out.println("Adding Team..");
		Team t=tList.save(p);
		return "<b>Added or inserted the product</b>"+t;
		
	}
   public String deleteTeam(String teamId)
   {
	   System.out.println("In Service. Deleteting the Team");
	   //For ex: if productId is 3
	   //When deleteById() is called, it converted this into
	   //SQL Delete from product where productId=3
	   tList.deleteById(teamId);
	   return "<b>Deleted team with ID</b>"+ teamId;
	   
   }
  
    public String searchById(String teamId) {
	 System.out.println("In service. Searching by the Id....");
	 //If productId is 4, this is converted to SQL
	 //SELECT*from Product where productId=4
	 Optional<Team> opt= tList.findById(teamId);
	 return "<b>Located Product</b>"+opt.get().toString();
	
	 
   }
   public String updateTeam(String teamId, String teamName)
   {
	   System.out.println("In service Updating Team");
	   Team d=new Team(teamId, teamName);
	   //when save() is called, if any product with
	   //given productId is existing, it updated productName with
	   //newProductname. Otherwise it inserts a new record.
	   tList.save(d);
	   return "<b>Updated product with"+tList.save(d).toString();
	 
	 
   }

}