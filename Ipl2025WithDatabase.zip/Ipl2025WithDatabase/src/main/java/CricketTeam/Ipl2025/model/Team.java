package CricketTeam.Ipl2025.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

//Linking the POJO class to the table in the database.
@Entity
@Table(name="Team")
public class Team {
	@Id //In the database this column is a primary key
	//For generating primary key values automatically
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="teamId")
	private String teamId;
	//Link productName variable with productName column in the database
	@Column(name="teamName")
	private String teamName;
 
	public Team() {
		super();
		System.out.println("New team Created...");
		}

	@Override
	public String toString() {
		return "Team [teamId=" + teamId + ", teamName=" + teamName + "]"+"   -   "+hashCode();
	}

	public Team(String teamId, String teamName) {
		super();
		this.teamId = teamId;
		this.teamName = teamName;
		System.out.println("New Team Created... With teamId and teamName");
	}

	public String getTeamId() {
		return teamId;
	}

	public void setTeamId(String teamId) {
		this.teamId = teamId;
		System.out.println("Stored teamId");
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
		System.out.println("Stored teamName");
	}
}
