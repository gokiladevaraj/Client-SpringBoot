package BackendDevelopers.FirstSpringBoot.dao;



import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;
import BackendDevelopers.FirstSpringBoot.model.Product;
@Repository
public interface ProductList extends CrudRepository<Product,Integer>{
	/*CrudRepository<Product, Integer> 
	 * product is the data that will inserted into the database
	 * or retrieved from the database.
	 * Integer is the datatype of the primary key.
	 */
	
}
